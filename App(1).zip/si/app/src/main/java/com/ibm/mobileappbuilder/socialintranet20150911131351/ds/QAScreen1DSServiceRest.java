
package com.ibm.mobileappbuilder.socialintranet20150911131351.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;
import retrofit.mime.TypedByteArray;
import retrofit.http.Part;
import retrofit.http.Multipart;

public interface QAScreen1DSServiceRest{

	@GET("/app/57ef5a359d17e00300d4d32a/r/qAScreen1DS")
	void queryQAScreen1DSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<QAScreen1DSItem>> cb);

	@GET("/app/57ef5a359d17e00300d4d32a/r/qAScreen1DS/{id}")
	void getQAScreen1DSItemById(@Path("id") String id, Callback<QAScreen1DSItem> cb);

	@DELETE("/app/57ef5a359d17e00300d4d32a/r/qAScreen1DS/{id}")
  void deleteQAScreen1DSItemById(@Path("id") String id, Callback<QAScreen1DSItem> cb);

  @POST("/app/57ef5a359d17e00300d4d32a/r/qAScreen1DS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<QAScreen1DSItem>> cb);

  @POST("/app/57ef5a359d17e00300d4d32a/r/qAScreen1DS")
  void createQAScreen1DSItem(@Body QAScreen1DSItem item, Callback<QAScreen1DSItem> cb);

  @PUT("/app/57ef5a359d17e00300d4d32a/r/qAScreen1DS/{id}")
  void updateQAScreen1DSItem(@Path("id") String id, @Body QAScreen1DSItem item, Callback<QAScreen1DSItem> cb);

  @GET("/app/57ef5a359d17e00300d4d32a/r/qAScreen1DS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
    
    @Multipart
    @POST("/app/57ef5a359d17e00300d4d32a/r/qAScreen1DS")
    void createQAScreen1DSItem(
        @Part("data") QAScreen1DSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<QAScreen1DSItem> cb);
    
    @Multipart
    @PUT("/app/57ef5a359d17e00300d4d32a/r/qAScreen1DS/{id}")
    void updateQAScreen1DSItem(
        @Path("id") String id,
        @Part("data") QAScreen1DSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<QAScreen1DSItem> cb);
}

