
package com.ibm.mobileappbuilder.socialintranet20150911131351.ui;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import com.ibm.mobileappbuilder.socialintranet20150911131351.R;
import ibmmobileappbuilder.ds.Datasource;
import android.widget.ImageView;
import android.widget.TextView;
import ibmmobileappbuilder.actions.ActivityIntentLauncher;
import ibmmobileappbuilder.actions.MapsAction;
import ibmmobileappbuilder.actions.PhoneAction;
import ibmmobileappbuilder.ds.restds.AppNowDatasource;
import ibmmobileappbuilder.util.image.ImageLoader;
import ibmmobileappbuilder.util.image.PicassoImageLoader;
import ibmmobileappbuilder.util.StringUtils;
import java.net.URL;
import static ibmmobileappbuilder.util.image.ImageLoaderRequest.Builder.imageLoaderRequest;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.socialintranet20150911131351.ds.ContactDSItem;
import com.ibm.mobileappbuilder.socialintranet20150911131351.ds.ContactDS;

public class ContactHRFragment extends ibmmobileappbuilder.ui.DetailFragment<ContactDSItem>  {

    private Datasource<ContactDSItem> datasource;
    private SearchOptions searchOptions;

    public static ContactHRFragment newInstance(Bundle args){
        ContactHRFragment card = new ContactHRFragment();
        card.setArguments(args);

        return card;
    }

    public ContactHRFragment(){
        super();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
            searchOptions = SearchOptions.Builder.searchOptions().build();
    }

    @Override
    public Datasource getDatasource() {
      if (datasource != null) {
          return datasource;
      }
          datasource = ContactDS.getInstance(searchOptions);
          return datasource;
    }

    // Bindings

    @Override
    protected int getLayout() {
        return R.layout.contacthr_custom;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final ContactDSItem item, View view) {
        
        ImageView view0 = (ImageView) view.findViewById(R.id.view0);
        URL view0Media = ((AppNowDatasource) getDatasource()).getImageUrl(item.picture);
        if(view0Media != null){
          ImageLoader imageLoader = new PicassoImageLoader(view0.getContext());
          imageLoader.load(imageLoaderRequest()
                                   .withPath(view0Media.toExternalForm())
                                   .withTargetView(view0)
                                   .fit()
                                   .build()
                    );
        	
        } else {
          view0.setImageDrawable(null);
        }
        if (item.whyContact != null){
            
            TextView view1 = (TextView) view.findViewById(R.id.view1);
            view1.setText(item.whyContact);
            
        }
        if (item.contact != null){
            
            TextView view2 = (TextView) view.findViewById(R.id.view2);
            view2.setText(item.contact);
            bindAction(view2, new MapsAction(
            new ActivityIntentLauncher()
            , "http://maps.google.com/maps?q=" + item.contact));
        }
        if (item.call != null){
            
            TextView view3 = (TextView) view.findViewById(R.id.view3);
            view3.setText(item.call);
            bindAction(view3, new PhoneAction(
            new ActivityIntentLauncher()
            , item.call));
        }
    }

    @Override
    protected void onShow(ContactDSItem item) {
        // set the title for this fragment
        getActivity().setTitle("Contact HR");
    }

}

