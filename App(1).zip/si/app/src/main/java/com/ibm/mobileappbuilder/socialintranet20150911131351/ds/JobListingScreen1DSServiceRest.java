
package com.ibm.mobileappbuilder.socialintranet20150911131351.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;
import retrofit.mime.TypedByteArray;
import retrofit.http.Part;
import retrofit.http.Multipart;

public interface JobListingScreen1DSServiceRest{

	@GET("/app/57ef5a359d17e00300d4d32a/r/jobListingScreen1DS")
	void queryJobListingScreen1DSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<JobListingScreen1DSItem>> cb);

	@GET("/app/57ef5a359d17e00300d4d32a/r/jobListingScreen1DS/{id}")
	void getJobListingScreen1DSItemById(@Path("id") String id, Callback<JobListingScreen1DSItem> cb);

	@DELETE("/app/57ef5a359d17e00300d4d32a/r/jobListingScreen1DS/{id}")
  void deleteJobListingScreen1DSItemById(@Path("id") String id, Callback<JobListingScreen1DSItem> cb);

  @POST("/app/57ef5a359d17e00300d4d32a/r/jobListingScreen1DS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<JobListingScreen1DSItem>> cb);

  @POST("/app/57ef5a359d17e00300d4d32a/r/jobListingScreen1DS")
  void createJobListingScreen1DSItem(@Body JobListingScreen1DSItem item, Callback<JobListingScreen1DSItem> cb);

  @PUT("/app/57ef5a359d17e00300d4d32a/r/jobListingScreen1DS/{id}")
  void updateJobListingScreen1DSItem(@Path("id") String id, @Body JobListingScreen1DSItem item, Callback<JobListingScreen1DSItem> cb);

  @GET("/app/57ef5a359d17e00300d4d32a/r/jobListingScreen1DS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
    
    @Multipart
    @POST("/app/57ef5a359d17e00300d4d32a/r/jobListingScreen1DS")
    void createJobListingScreen1DSItem(
        @Part("data") JobListingScreen1DSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<JobListingScreen1DSItem> cb);
    
    @Multipart
    @PUT("/app/57ef5a359d17e00300d4d32a/r/jobListingScreen1DS/{id}")
    void updateJobListingScreen1DSItem(
        @Path("id") String id,
        @Part("data") JobListingScreen1DSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<JobListingScreen1DSItem> cb);
}

