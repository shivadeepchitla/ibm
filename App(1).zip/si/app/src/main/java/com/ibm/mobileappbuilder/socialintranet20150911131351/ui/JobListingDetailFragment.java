
package com.ibm.mobileappbuilder.socialintranet20150911131351.ui;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.TextView;
import com.ibm.mobileappbuilder.socialintranet20150911131351.R;
import ibmmobileappbuilder.behaviors.ShareBehavior;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.socialintranet20150911131351.ds.JobListingScreen1DSItem;
import com.ibm.mobileappbuilder.socialintranet20150911131351.ds.JobListingScreen1DS;

public class JobListingDetailFragment extends ibmmobileappbuilder.ui.DetailFragment<JobListingScreen1DSItem> implements ShareBehavior.ShareListener  {

    private Datasource<JobListingScreen1DSItem> datasource;
    public static JobListingDetailFragment newInstance(Bundle args){
        JobListingDetailFragment fr = new JobListingDetailFragment();
        fr.setArguments(args);

        return fr;
    }

    public JobListingDetailFragment(){
        super();
    }

    @Override
    public Datasource<JobListingScreen1DSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = JobListingScreen1DS.getInstance(new SearchOptions());
        return datasource;
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        addBehavior(new ShareBehavior(getActivity(), this));

    }

    // Bindings

    @Override
    protected int getLayout() {
        return R.layout.joblistingdetail_detail;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final JobListingScreen1DSItem item, View view) {
        if (item.title != null){
            
            TextView view0 = (TextView) view.findViewById(R.id.view0);
            view0.setText(item.title);
            
        }
        if (item.description != null){
            
            TextView view1 = (TextView) view.findViewById(R.id.view1);
            view1.setText(item.description);
            
        }
        if (item.filter != null){
            
            TextView view2 = (TextView) view.findViewById(R.id.view2);
            view2.setText(item.filter);
            
        }
    }

    @Override
    protected void onShow(JobListingScreen1DSItem item) {
        // set the title for this fragment
        getActivity().setTitle(null);
    }
    @Override
    public void onShare() {
        JobListingScreen1DSItem item = getItem();

        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.setType("text/plain");

        intent.putExtra(Intent.EXTRA_TEXT, (item.title != null ? item.title : "" ) + "\n" +
                    (item.description != null ? item.description : "" ) + "\n" +
                    (item.filter != null ? item.filter : "" ));
        startActivityForResult(Intent.createChooser(intent, getString(R.string.share)), 1);
    }
}

