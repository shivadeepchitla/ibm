
package com.ibm.mobileappbuilder.socialintranet20150911131351.ds;
import java.net.URL;
import com.ibm.mobileappbuilder.socialintranet20150911131351.R;
import ibmmobileappbuilder.ds.RestService;
import ibmmobileappbuilder.util.StringUtils;

/**
 * "QAScreen1DSService" REST Service implementation
 */
public class QAScreen1DSService extends RestService<QAScreen1DSServiceRest>{

    public static QAScreen1DSService getInstance(){
          return new QAScreen1DSService();
    }

    private QAScreen1DSService() {
        super(QAScreen1DSServiceRest.class);

    }

    @Override
    public String getServerUrl() {
        return "https://ibm-pods.buildup.io";
    }

    @Override
    protected String getApiKey() {
        return "31pvb6HZ";
    }

    @Override
    public URL getImageUrl(String path){
        return StringUtils.parseUrl("https://ibm-pods.buildup.io/app/57ef5a359d17e00300d4d32a",
                path,
                "apikey=31pvb6HZ");
    }

}

