

package com.ibm.mobileappbuilder.socialintranet20150911131351.ui;

import android.os.Bundle;

import com.ibm.mobileappbuilder.socialintranet20150911131351.R;

import java.util.ArrayList;
import java.util.List;

import ibmmobileappbuilder.MenuItem;

import ibmmobileappbuilder.actions.StartActivityAction;
import ibmmobileappbuilder.util.Constants;

/**
 * HomeFragment menu fragment.
 */
public class HomeFragment extends ibmmobileappbuilder.ui.MenuFragment {

    /**
     * Default constructor
     */
    public HomeFragment(){
        super();
    }

    // Factory method
    public static HomeFragment newInstance(Bundle args) {
        HomeFragment fragment = new HomeFragment();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
      public void onCreate(Bundle savedInstanceState) {
          super.onCreate(savedInstanceState);
                }

    // Menu Fragment interface
    @Override
    public List<MenuItem> getMenuItems() {
        ArrayList<MenuItem> items = new ArrayList<MenuItem>();
        items.add(new MenuItem()
            .setLabel("Best Practices")
            .setIcon(R.drawable.png_branchoffice939)
            .setAction(new StartActivityAction(BestPracticesActivity.class, Constants.DETAIL))
        );
        items.add(new MenuItem()
            .setLabel("Job Listing")
            .setIcon(R.drawable.png_joblisting454)
            .setAction(new StartActivityAction(JobListingActivity.class, Constants.DETAIL))
        );
        items.add(new MenuItem()
            .setLabel("Q&A")
            .setIcon(R.drawable.png_qa463)
            .setAction(new StartActivityAction(QAActivity.class, Constants.DETAIL))
        );
        items.add(new MenuItem()
            .setLabel("Contact HR")
            .setIcon(R.drawable.png_contacthr267)
            .setAction(new StartActivityAction(ContactHRActivity.class, Constants.DETAIL))
        );
        return items;
    }

    @Override
    public int getLayout() {
        return R.layout.fragment_list;
    }

    @Override
    public int getItemLayout() {
        return R.layout.home_item;
    }
}

