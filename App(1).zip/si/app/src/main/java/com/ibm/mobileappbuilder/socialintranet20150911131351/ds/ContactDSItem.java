
package com.ibm.mobileappbuilder.socialintranet20150911131351.ds;
import android.graphics.Bitmap;
import android.net.Uri;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class ContactDSItem implements Parcelable, IdentifiableBean {

    @SerializedName("whyContact") public String whyContact;
    @SerializedName("contact") public String contact;
    @SerializedName("picture") public String picture;
    @SerializedName("call") public String call;
    @SerializedName("id") public String id;
    @SerializedName("pictureUri") public transient Uri pictureUri;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(whyContact);
        dest.writeString(contact);
        dest.writeString(picture);
        dest.writeString(call);
        dest.writeString(id);
    }

    public static final Creator<ContactDSItem> CREATOR = new Creator<ContactDSItem>() {
        @Override
        public ContactDSItem createFromParcel(Parcel in) {
            ContactDSItem item = new ContactDSItem();

            item.whyContact = in.readString();
            item.contact = in.readString();
            item.picture = in.readString();
            item.call = in.readString();
            item.id = in.readString();
            return item;
        }

        @Override
        public ContactDSItem[] newArray(int size) {
            return new ContactDSItem[size];
        }
    };

}


