
package com.ibm.mobileappbuilder.socialintranet20150911131351.ds;
import android.graphics.Bitmap;
import android.net.Uri;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class BestPracticesScreen1DSItem implements Parcelable, IdentifiableBean {

    @SerializedName("filter") public String filter;
    @SerializedName("title") public String title;
    @SerializedName("picture") public String picture;
    @SerializedName("description") public String description;
    @SerializedName("id") public String id;
    @SerializedName("pictureUri") public transient Uri pictureUri;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(filter);
        dest.writeString(title);
        dest.writeString(picture);
        dest.writeString(description);
        dest.writeString(id);
    }

    public static final Creator<BestPracticesScreen1DSItem> CREATOR = new Creator<BestPracticesScreen1DSItem>() {
        @Override
        public BestPracticesScreen1DSItem createFromParcel(Parcel in) {
            BestPracticesScreen1DSItem item = new BestPracticesScreen1DSItem();

            item.filter = in.readString();
            item.title = in.readString();
            item.picture = in.readString();
            item.description = in.readString();
            item.id = in.readString();
            return item;
        }

        @Override
        public BestPracticesScreen1DSItem[] newArray(int size) {
            return new BestPracticesScreen1DSItem[size];
        }
    };

}


