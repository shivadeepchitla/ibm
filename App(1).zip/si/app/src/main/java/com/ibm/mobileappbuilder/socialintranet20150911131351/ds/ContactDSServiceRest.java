
package com.ibm.mobileappbuilder.socialintranet20150911131351.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;
import retrofit.mime.TypedByteArray;
import retrofit.http.Part;
import retrofit.http.Multipart;

public interface ContactDSServiceRest{

	@GET("/app/57ef5a359d17e00300d4d32a/r/contactDS")
	void queryContactDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<ContactDSItem>> cb);

	@GET("/app/57ef5a359d17e00300d4d32a/r/contactDS/{id}")
	void getContactDSItemById(@Path("id") String id, Callback<ContactDSItem> cb);

	@DELETE("/app/57ef5a359d17e00300d4d32a/r/contactDS/{id}")
  void deleteContactDSItemById(@Path("id") String id, Callback<ContactDSItem> cb);

  @POST("/app/57ef5a359d17e00300d4d32a/r/contactDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<ContactDSItem>> cb);

  @POST("/app/57ef5a359d17e00300d4d32a/r/contactDS")
  void createContactDSItem(@Body ContactDSItem item, Callback<ContactDSItem> cb);

  @PUT("/app/57ef5a359d17e00300d4d32a/r/contactDS/{id}")
  void updateContactDSItem(@Path("id") String id, @Body ContactDSItem item, Callback<ContactDSItem> cb);

  @GET("/app/57ef5a359d17e00300d4d32a/r/contactDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
    
    @Multipart
    @POST("/app/57ef5a359d17e00300d4d32a/r/contactDS")
    void createContactDSItem(
        @Part("data") ContactDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<ContactDSItem> cb);
    
    @Multipart
    @PUT("/app/57ef5a359d17e00300d4d32a/r/contactDS/{id}")
    void updateContactDSItem(
        @Path("id") String id,
        @Part("data") ContactDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<ContactDSItem> cb);
}

