
package com.ibm.mobileappbuilder.socialintranet20150911131351.ui;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.TextView;
import com.ibm.mobileappbuilder.socialintranet20150911131351.R;
import ibmmobileappbuilder.behaviors.ShareBehavior;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.socialintranet20150911131351.ds.BestPracticesScreen1DSItem;
import com.ibm.mobileappbuilder.socialintranet20150911131351.ds.BestPracticesScreen1DS;

public class BestPracticesDetailFragment extends ibmmobileappbuilder.ui.DetailFragment<BestPracticesScreen1DSItem> implements ShareBehavior.ShareListener  {

    private Datasource<BestPracticesScreen1DSItem> datasource;
    public static BestPracticesDetailFragment newInstance(Bundle args){
        BestPracticesDetailFragment fr = new BestPracticesDetailFragment();
        fr.setArguments(args);

        return fr;
    }

    public BestPracticesDetailFragment(){
        super();
    }

    @Override
    public Datasource<BestPracticesScreen1DSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = BestPracticesScreen1DS.getInstance(new SearchOptions());
        return datasource;
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        addBehavior(new ShareBehavior(getActivity(), this));

    }

    // Bindings

    @Override
    protected int getLayout() {
        return R.layout.bestpracticesdetail_detail;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final BestPracticesScreen1DSItem item, View view) {
        if (item.title != null){
            
            TextView view0 = (TextView) view.findViewById(R.id.view0);
            view0.setText(item.title);
            
        }
        if (item.description != null){
            
            TextView view1 = (TextView) view.findViewById(R.id.view1);
            view1.setText(item.description);
            
        }
    }

    @Override
    protected void onShow(BestPracticesScreen1DSItem item) {
        // set the title for this fragment
        getActivity().setTitle("Best Practices");
    }
    @Override
    public void onShare() {
        BestPracticesScreen1DSItem item = getItem();

        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.setType("text/plain");

        intent.putExtra(Intent.EXTRA_TEXT, (item.title != null ? item.title : "" ) + "\n" +
                    (item.description != null ? item.description : "" ));
        intent.putExtra(Intent.EXTRA_SUBJECT, "Best Practices");
        startActivityForResult(Intent.createChooser(intent, getString(R.string.share)), 1);
    }
}

