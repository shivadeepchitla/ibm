package ibmmobileappbuilder.ds;

/**
 * Marker interface to be used on MapFragments to check if a datasource can display data in maps.
 */
public interface GeoDatasource {
}
